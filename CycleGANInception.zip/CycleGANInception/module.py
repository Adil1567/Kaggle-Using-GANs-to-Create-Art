import tensorflow as tf
import tensorflow_addons as tfa
import tensorflow.keras as keras


# ==============================================================================
# =                                  networks                                  =
# ==============================================================================

def _get_norm_layer(norm):
    if norm == 'none':
        return lambda: lambda x: x
    elif norm == 'batch_norm':
        return keras.layers.BatchNormalization
    elif norm == 'instance_norm':
        return tfa.layers.InstanceNormalization
    elif norm == 'layer_norm':
        return keras.layers.LayerNormalization


def ResnetGenerator(input_shape=(256, 256, 3),
                    output_channels=3,
                    dim=64,
                    n_downsamplings=2,
                    n_blocks=9,
                    norm='instance_norm'):
    Norm = _get_norm_layer(norm)

    def _residual_block(x):
        dim = x.shape[-1]
        h = x

        h = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        h = keras.layers.Conv2D(dim, 3, padding='valid', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.relu(h)

        h = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        h = keras.layers.Conv2D(dim, 3, padding='valid', use_bias=False)(h)
        h = Norm()(h)

        return keras.layers.add([x, h])

    # 0
    h = inputs = keras.Input(shape=input_shape)

    # 1
    h = tf.pad(h, [[0, 0], [3, 3], [3, 3], [0, 0]], mode='REFLECT')
    h = keras.layers.Conv2D(dim, 7, padding='valid', use_bias=False)(h)
    h = Norm()(h)
    h = tf.nn.relu(h)

    # 2
    for _ in range(n_downsamplings):
        dim *= 2
        h = keras.layers.Conv2D(dim, 3, strides=2, padding='same', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.relu(h)

    # 3
    for _ in range(n_blocks):
        h = _residual_block(h)

    # 4
    for _ in range(n_downsamplings):
        dim //= 2
        h = keras.layers.Conv2DTranspose(dim, 3, strides=2, padding='same', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.relu(h)

    # 5
    h = tf.pad(h, [[0, 0], [3, 3], [3, 3], [0, 0]], mode='REFLECT')
    h = keras.layers.Conv2D(output_channels, 7, padding='valid')(h)
    h = tf.tanh(h)

    return keras.Model(inputs=inputs, outputs=h)


def InceptionGenerator(input_shape=(256, 256, 3),
                    output_channels=3,
                    dim=64,
                    n_downsamplings=2,
                    n_blocks=3,
                    norm='instance_norm'):
    Norm = _get_norm_layer(norm)

    def _inception_module(x, 
                    dim1=(24, 48),
                    dim2=(128, 192),
                    dim3=64,
                    dim4=32):
        dim = x.shape[-1]
        print("DIM: ", dim)

        # 1x1 -> 3x3 -> 3x3 branch of inception module
        branch1 = x
        
        branch1 = keras.layers.Conv2D(dim1[0], 1, padding='valid', use_bias=False)(branch1)
        branch1 = Norm()(branch1)
        branch1 = tf.nn.relu(branch1)

        branch1 = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        branch1 = keras.layers.Conv2D(dim1[1], 3, padding='valid', use_bias=False)(branch1)
        branch1 = Norm()(branch1)
        branch1 = tf.nn.relu(branch1)

        branch1 = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        branch1 = keras.layers.Conv2D(dim1[1], 3, padding='valid', use_bias=False)(branch1)
        branch1 = Norm()(branch1)
        branch1 = tf.nn.relu(branch1)
        
        # 1x1 -> 3x3 branch
        branch2 = x
        
        branch2 = keras.layers.Conv2D(dim2[0], 1, padding='valid', use_bias=False)(branch2)
        branch2 = Norm()(branch2)
        branch2 = tf.nn.relu(branch2)

        branch2 = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        branch2 = keras.layers.Conv2D(dim2[1], 3, padding='valid', use_bias=False)(branch2)
        branch2 = Norm()(branch2)
        branch2 = tf.nn.relu(branch2)

        # 1x1 branch
        branch3 = x
        
        branch3 = keras.layers.Conv2D(dim3, 1, padding='valid', use_bias=False)(branch3)
        branch3 = Norm()(branch3)
        branch3 = tf.nn.relu(branch3)

        
        # # pool branch
        # branch4 = x
        
        # branch4 = tf.pad(h, [[0, 0], [1, 0], [1, 0], [0, 0]], mode='REFLECT')
        # branch4 = keras.layers.MaxPooling2D((2, 2), strides=(1, 1), padding='valid')(branch4)

        # # branch4 = tf.pad(h, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
        # branch4 = keras.layers.Conv2D(dim4, 1, padding='valid', use_bias=False)(branch4)
        # branch4 = Norm()(branch4)
        # branch4 = tf.nn.relu(branch4)


        return keras.layers.concatenate([branch1, branch2, branch3])

    # 0
    h = inputs = keras.Input(shape=input_shape)

    # 1
    h = tf.pad(h, [[0, 0], [3, 3], [3, 3], [0, 0]], mode='REFLECT')
    h = keras.layers.Conv2D(dim, 7, padding='valid', use_bias=False)(h)
    h = Norm()(h)
    h = tf.nn.relu(h)

    # 2
    for _ in range(n_downsamplings):
        dim *= 2
        h = keras.layers.Conv2D(dim, 3, strides=2, padding='same', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.relu(h)

    # 3
    # for _ in range(n_blocks):
    #     h = _inception_module(h)
    # h = _inception_module(h)
    # h = _inception_module(h, dim1=(32, 64), dim2=(112, 224), dim3=160)
    h = _inception_module(h, dim1=(24, 64), dim2=(128, 256), dim3=128)
    h = _inception_module(h, dim1=(32, 64), dim2=(144, 288), dim3=112)

    h = _inception_module(h, dim1=(32, 128), dim2=(160, 320), dim3=256)

    h = _inception_module(h, dim1=(32, 64), dim2=(144, 288), dim3=112)
    h = _inception_module(h, dim1=(24, 64), dim2=(128, 256), dim3=128)
    # h = _inception_module(h, dim1=(32, 64), dim2=(112, 224), dim3=160)
    # h = _inception_module(h)

    # 4
    for _ in range(n_downsamplings):
        dim //= 2
        h = keras.layers.Conv2DTranspose(dim, 3, strides=2, padding='same', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.relu(h)

    # 5
    h = tf.pad(h, [[0, 0], [3, 3], [3, 3], [0, 0]], mode='REFLECT')
    h = keras.layers.Conv2D(output_channels, 7, padding='valid')(h)
    h = tf.tanh(h)

    return keras.Model(inputs=inputs, outputs=h)


def ConvDiscriminator(input_shape=(256, 256, 3),
                      dim=64,
                      n_downsamplings=3,
                      norm='instance_norm'):
    dim_ = dim
    Norm = _get_norm_layer(norm)

    # 0
    h = inputs = keras.Input(shape=input_shape)

    # 1
    h = keras.layers.Conv2D(dim, 4, strides=2, padding='same')(h)
    h = tf.nn.leaky_relu(h, alpha=0.2)

    for _ in range(n_downsamplings - 1):
        dim = min(dim * 2, dim_ * 8)
        h = keras.layers.Conv2D(dim, 4, strides=2, padding='same', use_bias=False)(h)
        h = Norm()(h)
        h = tf.nn.leaky_relu(h, alpha=0.2)

    # 2
    dim = min(dim * 2, dim_ * 8)
    h = keras.layers.Conv2D(dim, 4, strides=1, padding='same', use_bias=False)(h)
    h = Norm()(h)
    h = tf.nn.leaky_relu(h, alpha=0.2)

    # 3
    h = keras.layers.Conv2D(1, 4, strides=1, padding='same')(h)

    return keras.Model(inputs=inputs, outputs=h)


# ==============================================================================
# =                          learning rate scheduler                           =
# ==============================================================================

class LinearDecay(keras.optimizers.schedules.LearningRateSchedule):
    # if `step` < `step_decay`: use fixed learning rate
    # else: linearly decay the learning rate to zero

    def __init__(self, initial_learning_rate, total_steps, step_decay):
        super(LinearDecay, self).__init__()
        self._initial_learning_rate = initial_learning_rate
        self._steps = total_steps
        self._step_decay = step_decay
        self.current_learning_rate = tf.Variable(initial_value=initial_learning_rate, trainable=False, dtype=tf.float32)

    def __call__(self, step):
        self.current_learning_rate.assign(
            self._initial_learning_rate
        # tf.cond(
        #     step >= self._step_decay,
        #     true_fn=lambda: self._initial_learning_rate * (1 - 1 / (self._steps - self._step_decay) * (step - self._step_decay)),
        #     false_fn=lambda: self._initial_learning_rate
        # )
        )
        return self.current_learning_rate
